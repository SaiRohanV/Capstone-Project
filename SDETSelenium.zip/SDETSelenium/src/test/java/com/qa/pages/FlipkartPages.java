package com.qa.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FlipkartPages {

	WebDriver driver;
	
	@FindBy(xpath="//button[@class=\"_2KpZ6l _2doB4z\"]")
	WebElement closeBtn;
	
	public WebElement getCloseBtn() {
		return closeBtn;
	}
	
	@FindBy(xpath="//img[@title=\"Flipkart\"]")
	WebElement FlipkartLogo;
	
	public WebElement getFlipkartLogo() {
		return FlipkartLogo;
	}
	
	@FindBy(name="q")
	WebElement SearchBar;
	
	public WebElement getSearchBar() {
		return SearchBar;
	}
	
	@FindBy(className="_4rR01T")
	WebElement firstItem;
	
	public WebElement getFirstItem() {
		return firstItem;
	}
	
	@FindAll(@FindBy(className="_4rR01T"))
	List< WebElement> allitems;
	
	public List< WebElement> getallitems(){
		 return allitems;
	 }
	
	public FlipkartPages(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver,this); 
	}

}
