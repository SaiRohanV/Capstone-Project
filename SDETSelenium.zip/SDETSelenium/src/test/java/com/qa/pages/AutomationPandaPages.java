package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AutomationPandaPages {

	WebDriver driver;
	
	@FindBy(xpath="//a[text()='Contact']")
	WebElement contact;
	
	public WebElement getContact() {
		return contact;
	}
	
	@FindBy(xpath="//input[@class=\"name  grunion-field\"]")
	WebElement name;
	
	public WebElement getName() {
		return name;
	}
	
	@FindBy(xpath="//input[@class=\"email  grunion-field\"]")
	WebElement email;
	
	public WebElement getEmail() {
		return email;
	}
	
	@FindBy(xpath="//textarea[@class=\"textarea  grunion-field\"]")
	WebElement message;
	
	public WebElement getMessage() {
		return message;
	}
	
	@FindBy(xpath="//strong[text()='Contact Me']")
	WebElement ContactMeBtn;
	
	public WebElement getContactMeBtn() {
		return ContactMeBtn;
	}
	
	@FindBy(id="contact-form-success-header")
	WebElement SuccessMsg;
	
	public WebElement getSuccessMsg() {
		return SuccessMsg;
	}
	
	public AutomationPandaPages(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver,this); 
	}

}
