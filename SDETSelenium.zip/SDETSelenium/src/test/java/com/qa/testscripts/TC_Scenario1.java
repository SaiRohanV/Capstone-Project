package com.qa.testscripts;

import org.testng.annotations.Test;

public class TC_Scenario1 extends TestBase{
	
	@Test
	public void verify() {
		if(driver.getTitle().contains("Automation")) {
			System.out.println("Navigated to Automation panda page");
		}
		else {
			System.out.println("Not navigated to automation panda page");
		}
		
		AutomationPandaPagesOR.getContact().click();
		if(driver.getTitle().contains("Contact")) {
			System.out.println("Navigated to Contact page");
		}
		else {
			System.out.println("Not navigated to Contact page");
		}
		
		AutomationPandaPagesOR.getName().sendKeys("Panda");
		AutomationPandaPagesOR.getEmail().sendKeys("panda@gmail.com");
		AutomationPandaPagesOR.getMessage().sendKeys("This is a message");
		AutomationPandaPagesOR.getContactMeBtn().click();
		if(AutomationPandaPagesOR.getSuccessMsg().isDisplayed()) {
			System.out.println("Success Message is displayed");
		}else {
			System.out.println("Success Message is not displayed");
		}
		
	}

}
