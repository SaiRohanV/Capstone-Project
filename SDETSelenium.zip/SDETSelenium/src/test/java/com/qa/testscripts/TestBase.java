package com.qa.testscripts;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.qa.pages.AutomationPandaPages;
import com.qa.pages.FlipkartPages;

public class TestBase {

	String Browser ="chrome";
	WebDriver driver;
	AutomationPandaPages AutomationPandaPagesOR;
	FlipkartPages FlipkartOR;
    
	@BeforeClass
	@Parameters({"Browser", "url"})
	public void Setup(String Browser,String url) throws IOException {
	if(Browser.equalsIgnoreCase("chrome")) {
				
		System.setProperty("webdriver.chrome.driver", "D:\\18311A05P8\\Virtusa training\\chromedriver_win32\\chromedriver.exe");
				
				 driver  = new  ChromeDriver();
				
			}else if(Browser.equalsIgnoreCase("Firefox")) {
				
				System.setProperty("webdriver.gecko.driver", "C:\\TTT\\Drivers\\geckodriver.exe");
				
	       		driver  = new  FirefoxDriver();		
			}
			
			driver.get(url); 
			driver.manage().window().maximize();
			AutomationPandaPagesOR = new AutomationPandaPages(driver);  
			FlipkartOR = new FlipkartPages(driver);
			
	}
	@AfterClass
	public void Teardown()
	{
		//driver.close();
		driver.quit();
	}
}

