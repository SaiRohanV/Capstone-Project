package com.qa.testscripts;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.qa.pages.FlipkartPages;

public class TC_Scenario2 extends TestBase {
	
	@Test
	public void verify() throws Exception {
		
		Thread.sleep(2000);
		if(FlipkartOR.getCloseBtn().isDisplayed()) {
			FlipkartOR.getCloseBtn().click();
		}
		
		Thread.sleep(2000);
		if(FlipkartOR.getFlipkartLogo().isDisplayed()) {
			System.out.println("Flipkart is displayed");
		}
		else {
			System.out.println("Flipkart is not displayed");
		}
		
		Thread.sleep(2000);
		FlipkartOR.getSearchBar().sendKeys("iphone 14");
		FlipkartOR.getSearchBar().sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		System.out.println(FlipkartOR.getallitems().size());
		Thread.sleep(2000);
		FlipkartOR.getFirstItem().click();
		
		Thread.sleep(3000);
		
		Set<String> winid = driver.getWindowHandles();
		Iterator<String> iter = winid.iterator();
		while(iter.hasNext()) {
			
			String id =iter.next();
			WebDriver window =driver.switchTo().window(id);
			System.out.println(window.getTitle());
			if(window.getTitle().contains("14")) {
				System.out.println("Right page is displayed");
			}
			else {
				System.out.println("Wrong item is displayed");
			}
  		}
	}

}
